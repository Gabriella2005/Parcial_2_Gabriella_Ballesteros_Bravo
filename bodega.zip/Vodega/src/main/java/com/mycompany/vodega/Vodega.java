package com.mycompany.vodega;

public class Vodega {

    public static void main(String[] args) {
        
    }
}
