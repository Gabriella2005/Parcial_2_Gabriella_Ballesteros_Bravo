package modelView;
import view.op1;
import view.op2;

public class Procesos {
    
    static op1 escogio1 = new op1();
    static op2 escogio2 = new op2();
    
    public static void opcion1(){
        escogio1.setVisible(true);
    }
    
    public static void opcion2(){
        escogio2.setVisible(true);
    }
}
