package model;

import java.util.Map;
import view.SignUp;


public abstract class Productos extends SignUp{
    public abstract void producto(
            String coleccion,
            String documento,
            Map<String, Object> data);

}
