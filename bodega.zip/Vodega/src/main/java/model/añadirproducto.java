
package model;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class añadirproducto extends Productos{
    Firestore firestore;
    @Override
    public void producto(
            String coleccion,
            String documento,
            
            //crear un mapa para guardar los respectivos datos
            Map<String, Object> data) {
        try {
            if (firestore != null) {
                DocumentReference docRef = firestore.collection(coleccion).document(documento);
                ApiFuture<WriteResult> result = docRef.set(data);
                System.out.println("" + result.get().getUpdateTime());
            }
        } catch (InterruptedException | ExecutionException e) {
        }
    }
    
}
